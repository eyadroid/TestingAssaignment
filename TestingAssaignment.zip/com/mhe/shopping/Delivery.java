package com.mhe.shopping;

public class Delivery {
    String id;
    String name;
    double price;
}
