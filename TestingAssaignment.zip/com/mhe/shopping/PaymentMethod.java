package com.mhe.shopping;

public enum PaymentMethod {
    mbok,
    cash
}